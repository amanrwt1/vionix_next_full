import { NextRequest, NextResponse } from 'next/server'
import OpenAI from 'openai'
import { moderateInput } from '@/lib/safety'
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json()
    const last = messages?.[messages.length-1]?.content || ''
    const mod = await moderateInput(last)
    if (!mod.safe) return NextResponse.json({ reply: mod.message })
    const sys = { role:'system' as const, content:'You are Vionix — concise, helpful, safe.'}
    const completion = await openai.chat.completions.create({ model:'gpt-4o-mini', temperature:0.2, max_tokens:500, messages:[sys, ...(messages||[])] })
    const reply = completion.choices?.[0]?.message?.content ?? 'Sorry, no reply.'
    return NextResponse.json({ reply })
  } catch (e:any) { return NextResponse.json({ error: e?.message || 'server error' }, { status: 500 }) }
}
