import VionixChat from '../components/VionixChat'
export default function Page(){ return <main><VionixChat/></main> }
