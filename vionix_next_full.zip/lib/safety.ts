import OpenAI from 'openai'
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
export async function moderateInput(text: string): Promise<{safe:boolean, message:string}> { if (!text) return { safe: true, message: '' }; try { const mod = await openai.moderations.create({ model: 'omni-moderation-latest', input: text }); if (mod.results?.[0]?.flagged) return { safe:false, message:'Maaf kijiye, yeh request policy ke khilaaf lag rahi hai.' } } catch {} return { safe:true, message:'' } }
